from .scan import main; main()
