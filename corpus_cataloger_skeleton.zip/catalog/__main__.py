print('Run as: python -m catalog.scan or python -m catalog.export')
